using System.Globalization;
using System;

namespace project
{
    class Program
    {
        static void Main(string[] args){
        }
    }
}